use(function () {
    return {
        message: 'hello world'
    };
});
